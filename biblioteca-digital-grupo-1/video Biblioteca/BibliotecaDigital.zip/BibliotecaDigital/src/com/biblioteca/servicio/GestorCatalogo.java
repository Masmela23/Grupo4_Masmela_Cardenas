package com.biblioteca.servicio;

import com.biblioteca.modelo.RecursoDigital;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

// SRP: solo gestiona el catálogo (agregar, buscar, listar)
// DIP: trabaja con la abstracción RecursoDigital, no con clases concretas
public class GestorCatalogo {

    private List<RecursoDigital> recursos;

    public GestorCatalogo() {
        this.recursos = new ArrayList<>();
    }

    public void agregarRecurso(RecursoDigital recurso) {
        recursos.add(recurso);
        System.out.println("✅ Recurso agregado: " + recurso.getDescripcion());
    }

    public RecursoDigital buscarPorTitulo(String titulo) {
        return recursos.stream()
                .filter(r -> r.getTitulo().equalsIgnoreCase(titulo))
                .findFirst()
                .orElse(null);
    }

    public List<RecursoDigital> listarDisponibles() {
        return recursos.stream()
                .filter(RecursoDigital::isDisponible)
                .collect(Collectors.toList());
    }

    public List<RecursoDigital> listarTodos() {
        return recursos;
    }

    public void mostrarCatalogo() {
        System.out.println("\n=== CATÁLOGO COMPLETO ===");
        if (recursos.isEmpty()) {
            System.out.println("El catálogo está vacío.");
            return;
        }
        recursos.forEach(RecursoDigital::mostrarInformacion);
        System.out.println("========================\n");
    }
}