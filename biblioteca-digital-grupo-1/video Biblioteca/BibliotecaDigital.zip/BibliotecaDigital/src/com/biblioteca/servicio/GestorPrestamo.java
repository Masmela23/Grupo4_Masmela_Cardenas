package com.biblioteca.servicio;

import com.biblioteca.interfaces.Prestable;
import com.biblioteca.interfaces.Notificable;
import com.biblioteca.modelo.Prestamo;
import com.biblioteca.modelo.RecursoDigital;
import com.biblioteca.modelo.Usuario;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

// SRP: solo gestiona préstamos y devoluciones
// DIP: usa Prestable y Notificable (abstracciones), no clases concretas
public class GestorPrestamo {

    private List<Prestamo> prestamos;
    private int contadorId;

    public GestorPrestamo() {
        this.prestamos = new ArrayList<>();
        this.contadorId = 1;
    }

    public Prestamo realizarPrestamo(RecursoDigital recurso, Usuario usuario) {
        if (!(recurso instanceof Prestable)) {
            System.out.println("⚠ El recurso no es prestable.");
            return null;
        }
        if (!recurso.isDisponible()) {
            System.out.println("⚠ El recurso '" + recurso.getTitulo() + "' no está disponible.");
            return null;
        }

        Prestable prestable = (Prestable) recurso;
        prestable.prestar(usuario);

        String id = "P" + String.format("%03d", contadorId++);
        Prestamo prestamo = new Prestamo(id, recurso, usuario, "2026-04-28", "2026-05-28");
        prestamos.add(prestamo);
        usuario.agregarPrestamo(prestamo);

        // DIP: notificamos al usuario a través de la abstracción Notificable
        if (usuario instanceof Notificable) {
            ((Notificable) usuario).enviarNotificacion(
                    "Préstamo registrado: '" + recurso.getTitulo() + "'. Vence: 2026-05-28"
            );
        }

        return prestamo;
    }

    public void devolverPrestamo(Prestamo prestamo) {
        Prestable prestable = (Prestable) prestamo.getRecurso();
        prestable.devolver();
        prestamo.finalizar();

        if (prestamo.getUsuario() instanceof Notificable) {
            ((Notificable) prestamo.getUsuario()).enviarNotificacion(
                    "Devolución registrada: '" + prestamo.getRecurso().getTitulo() + "'. ¡Gracias!"
            );
        }
    }

    public List<Prestamo> getPorUsuario(Usuario usuario) {
        return prestamos.stream()
                .filter(p -> p.getUsuario().getId().equals(usuario.getId()))
                .collect(Collectors.toList());
    }

    public void mostrarPrestamos() {
        System.out.println("\n=== PRÉSTAMOS ACTIVOS ===");
        prestamos.stream()
                .filter(Prestamo::isActivo)
                .forEach(System.out::println);
        System.out.println("========================\n");
    }
}