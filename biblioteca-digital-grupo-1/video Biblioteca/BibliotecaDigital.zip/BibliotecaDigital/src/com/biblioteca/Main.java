package com.biblioteca;

import com.biblioteca.interfaces.Descargable;
import com.biblioteca.modelo.*;
import com.biblioteca.servicio.GestorCatalogo;
import com.biblioteca.servicio.GestorPrestamo;
public class Main {

    public static void main(String[] args) {

        System.out.println("╔══════════════════════════════════════════╗");
        System.out.println("║   SISTEMA DE GESTIÓN DE BIBLIOTECA       ║");
        System.out.println("║   DIGITAL — Grupo 1 — Corhuila 2026      ║");
        System.out.println("╚══════════════════════════════════════════╝\n");

        // ── 1. Crear servicios (DIP: dependemos de abstracciones) ──────────
        GestorCatalogo catalogo = new GestorCatalogo();
        GestorPrestamo gestorPrestamo = new GestorPrestamo();

        // ── 2. Crear recursos digitales ────────────────────────────────────
        Libro libro1 = new Libro("L001", "CIEN AÑOS DE SOLEDAD", "Gabriel G. Marquez", 1967,
                "978-84-376-0494-7", 448, "Clásico");
        Libro libro2 = new Libro("L002", "La Biblia de los Caidos", "Fernando.T Sanz", 2011,
                "978-0-13-235088-4", 464, "Fantasia");
        Revista revista1 = new Revista("R001", "IEEE Software", "IEEE", 2024, 12, "Tecnología");
        AudioLibro audio1 = new AudioLibro("A001", "La Divina Comedia", "Dante Alighieri", 1320,
                720, "Don Filosofo");

        // ── 3. Poblar catálogo (OCP: se agrega sin modificar GestorCatalogo) ─
        catalogo.agregarRecurso(libro1);
        catalogo.agregarRecurso(libro2);
        catalogo.agregarRecurso(revista1);
        catalogo.agregarRecurso(audio1);

        // ── 4. Mostrar catálogo completo ───────────────────────────────────
        catalogo.mostrarCatalogo();

        // ── 5. Crear usuarios ──────────────────────────────────────────────
        Usuario usuario1 = new Usuario("U001", "Fernando Masmela", "lfmasmela-2025@corhuila.edu.co");
        Usuario usuario2 = new Usuario("U002", "Keneth Cardenas", "krcardenas-2025@corhuila.edu.co");

        // ── 6. Realizar préstamos (polimorfismo LSP) ───────────────────────
        System.out.println("=== PRÉSTAMOS ===");
        gestorPrestamo.realizarPrestamo(libro1, usuario1);
        gestorPrestamo.realizarPrestamo(revista1, usuario2);
        gestorPrestamo.realizarPrestamo(audio1, usuario1);
        // Intento de préstamo cuando no está disponible:
        gestorPrestamo.realizarPrestamo(libro1, usuario2);

        // ── 7. Descargas (ISP: solo recursos Descargable) ─────────────────
        System.out.println("\n=== DESCARGAS ===");
        catalogo.listarTodos().forEach(r -> {
            if (r instanceof Descargable) {
                System.out.println(((Descargable) r).descargar());
            }
        });

        // ── 8. Ver préstamos activos ───────────────────────────────────────
        gestorPrestamo.mostrarPrestamos();

        // ── 9. Devolver un recurso ─────────────────────────────────────────
        System.out.println("=== DEVOLUCIÓN ===");
        var prestamosUsuario1 = gestorPrestamo.getPorUsuario(usuario1);
        if (!prestamosUsuario1.isEmpty()) {
            gestorPrestamo.devolverPrestamo(prestamosUsuario1.get(0));
        }

        // ── 10. Estado final del catálogo ──────────────────────────────────
        System.out.println("\n=== DISPONIBLES DESPUÉS DE DEVOLUCIÓN ===");
        catalogo.listarDisponibles().forEach(r -> System.out.println("  ✔ " + r.getDescripcion()));

        System.out.println("\n✅ Demostración completada.");
    }
}