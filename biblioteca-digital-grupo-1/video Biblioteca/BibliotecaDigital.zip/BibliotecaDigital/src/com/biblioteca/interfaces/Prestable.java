package com.biblioteca.interfaces;

import com.biblioteca.modelo.Usuario;

// ISP: interfaz específica solo para préstamo/devolución
public interface Prestable {
    void prestar(Usuario usuario);
    void devolver();
}
