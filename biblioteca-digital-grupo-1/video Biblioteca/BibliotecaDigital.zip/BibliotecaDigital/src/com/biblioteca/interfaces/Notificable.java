package com.biblioteca.interfaces;

public interface Notificable {
    void enviarNotificacion(String mensaje);
}