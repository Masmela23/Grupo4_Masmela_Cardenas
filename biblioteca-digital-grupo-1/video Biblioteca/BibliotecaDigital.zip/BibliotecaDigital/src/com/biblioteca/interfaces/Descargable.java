package com.biblioteca.interfaces;

public interface Descargable {
    String descargar();
}
