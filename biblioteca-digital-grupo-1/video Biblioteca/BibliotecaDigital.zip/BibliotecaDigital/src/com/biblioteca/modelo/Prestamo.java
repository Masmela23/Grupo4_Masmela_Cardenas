package com.biblioteca.modelo;

// SRP: solo representa el registro de un préstamo
public class Prestamo {

    private String id;
    private RecursoDigital recurso;
    private Usuario usuario;
    private String fechaInicio;
    private String fechaVencimiento;
    private boolean activo;

    public Prestamo(String id, RecursoDigital recurso, Usuario usuario,
                    String fechaInicio, String fechaVencimiento) {
        this.id = id;
        this.recurso = recurso;
        this.usuario = usuario;
        this.fechaInicio = fechaInicio;
        this.fechaVencimiento = fechaVencimiento;
        this.activo = true;
    }

    public void finalizar() {
        this.activo = false;
        System.out.println("📋 Préstamo " + id + " finalizado.");
    }

    public boolean estaVencido() {
        // Lógica simplificada — en producción usar LocalDate
        return false;
    }

    public String getId()              { return id; }
    public RecursoDigital getRecurso() { return recurso; }
    public Usuario getUsuario()        { return usuario; }
    public String getFechaInicio()     { return fechaInicio; }
    public String getFechaVencimiento(){ return fechaVencimiento; }
    public boolean isActivo()          { return activo; }

    @Override
    public String toString() {
        return "Préstamo[" + id + "] " + recurso.getTitulo() + " → " + usuario.getNombre()
                + " | Hasta: " + fechaVencimiento + " | Activo: " + activo;
    }
}
