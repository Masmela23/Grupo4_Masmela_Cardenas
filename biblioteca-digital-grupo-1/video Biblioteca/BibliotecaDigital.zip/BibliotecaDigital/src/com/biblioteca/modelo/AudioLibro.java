package com.biblioteca.modelo;

import com.biblioteca.interfaces.Prestable;

// ISP: Audiolibro NO implementa Descargable (se reproduce, no se descarga como PDF)
public class AudioLibro extends RecursoDigital implements Prestable {

    private int duracionMinutos;
    private String narrador;

    public AudioLibro(String id, String titulo, String autor, int anio,
                      int duracionMinutos, String narrador) {
        super(id, titulo, autor, anio);
        this.duracionMinutos = duracionMinutos;
        this.narrador = narrador;
    }

    @Override
    public void mostrarInformacion() {
        System.out.println("🎧 AUDIOLIBRO: " + getTitulo());
        System.out.println("   Autor: " + getAutor() + " | Año: " + getAnioPublicacion());
        System.out.println("   Duración: " + duracionMinutos + " min | Narrador: " + narrador);
        System.out.println("   Disponible: " + (isDisponible() ? "Sí" : "No"));
    }

    @Override
    public String getDescripcion() {
        return "Audiolibro '" + getTitulo() + "' narrado por " + narrador + " (" + duracionMinutos + " min)";
    }

    @Override
    public void prestar(Usuario usuario) {
        if (!isDisponible()) {
            System.out.println("⚠ El audiolibro '" + getTitulo() + "' no está disponible.");
            return;
        }
        setDisponible(false);
        System.out.println("✅ Audiolibro '" + getTitulo() + "' prestado a " + usuario.getNombre());
    }

    @Override
    public void devolver() {
        setDisponible(true);
        System.out.println("✅ Audiolibro '" + getTitulo() + "' devuelto.");
    }

    public String reproducir() {
        return "▶ Reproduciendo audiolibro '" + getTitulo() + "'...";
    }

    public int getDuracionMinutos() { return duracionMinutos; }
    public String getNarrador()     { return narrador; }
}
