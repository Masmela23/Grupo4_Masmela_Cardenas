package com.biblioteca.modelo;

import com.biblioteca.interfaces.Prestable;
import com.biblioteca.interfaces.Descargable;

// LSP: Libro puede sustituir a RecursoDigital sin romper el contrato
// ISP: implementa solo las interfaces que necesita
public class Libro extends RecursoDigital implements Prestable, Descargable {

    private String isbn;
    private int numeroPaginas;
    private String genero;

    public Libro(String id, String titulo, String autor, int anio,
                 String isbn, int paginas, String genero) {
        super(id, titulo, autor, anio);
        this.isbn = isbn;
        this.numeroPaginas = paginas;
        this.genero = genero;
    }

    @Override
    public void mostrarInformacion() {
        System.out.println("📖 LIBRO: " + getTitulo());
        System.out.println("   Autor: " + getAutor() + " | Año: " + getAnioPublicacion());
        System.out.println("   ISBN: " + isbn + " | Páginas: " + numeroPaginas + " | Género: " + genero);
        System.out.println("   Disponible: " + (isDisponible() ? "Sí" : "No"));
    }

    @Override
    public String getDescripcion() {
        return "Libro '" + getTitulo() + "' de " + getAutor() + " (" + numeroPaginas + " pág.)";
    }

    @Override
    public void prestar(Usuario usuario) {
        if (!isDisponible()) {
            System.out.println("⚠ El libro '" + getTitulo() + "' no está disponible.");
            return;
        }
        setDisponible(false);
        System.out.println("✅ Libro '" + getTitulo() + "' prestado a " + usuario.getNombre());
    }

    @Override
    public void devolver() {
        setDisponible(true);
        System.out.println("✅ Libro '" + getTitulo() + "' devuelto al catálogo.");
    }

    @Override
    public String descargar() {
        return "⬇ Descargando libro '" + getTitulo() + "' en formato PDF...";
    }

    public String getIsbn()       { return isbn; }
    public int getNumeroPaginas() { return numeroPaginas; }
    public String getGenero()     { return genero; }
}