package com.biblioteca.modelo;

// OCP: clase base abierta para extensión (nuevos recursos)
// SRP: solo representa un recurso digital con sus datos
public abstract class RecursoDigital {

    private String id;
    private String titulo;
    private String autor;
    private int anioPublicacion;
    private boolean disponible;

    public RecursoDigital(String id, String titulo, String autor, int anioPublicacion) {
        this.id = id;
        this.titulo = titulo;
        this.autor = autor;
        this.anioPublicacion = anioPublicacion;
        this.disponible = true;
    }

    // Métodos abstractos que cada subclase debe implementar (OCP + LSP)
    public abstract void mostrarInformacion();
    public abstract String getDescripcion();

    // Getters y setters
    public String getId()                     { return id; }
    public String getTitulo()                 { return titulo; }
    public String getAutor()                  { return autor; }
    public int    getAnioPublicacion()        { return anioPublicacion; }
    public boolean isDisponible()             { return disponible; }
    public void setDisponible(boolean disp)   { this.disponible = disp; }
}