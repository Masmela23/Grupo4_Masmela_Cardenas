package com.biblioteca.modelo;

import com.biblioteca.interfaces.Notificable;
import java.util.ArrayList;
import java.util.List;

// SRP: solo gestiona datos del usuario y su lista de préstamos
// Notificable: el usuario puede recibir notificaciones (DIP)
public class Usuario implements Notificable {

    private String id;
    private String nombre;
    private String email;
    private List<Prestamo> prestamos;

    public Usuario(String id, String nombre, String email) {
        this.id = id;
        this.nombre = nombre;
        this.email = email;
        this.prestamos = new ArrayList<>();
    }

    public void agregarPrestamo(Prestamo prestamo) {
        prestamos.add(prestamo);
    }

    @Override
    public void enviarNotificacion(String mensaje) {
        System.out.println("📩 Notificación para " + nombre + " (" + email + "): " + mensaje);
    }

    public String getId()               { return id; }
    public String getNombre()           { return nombre; }
    public String getEmail()            { return email; }
    public List<Prestamo> getPrestamos() { return prestamos; }
}