package com.biblioteca.modelo;

import java.time.LocalDate;

public class Reserva {
    private String idReserva;
    private Usuario usuario;
    private RecursoDigital recurso;
    private LocalDate fechaReserva;
    private boolean activa;

    public Reserva(String idReserva, Usuario usuario, RecursoDigital recurso) {
        this.idReserva = idReserva;
        this.usuario = usuario;
        this.recurso = recurso;
        this.fechaReserva = LocalDate.now();
        this.activa = true;
    }

    // Getters y Setters
    public String getIdReserva() { return idReserva; }
    public Usuario getUsuario() { return usuario; }
    public RecursoDigital getRecurso() { return recurso; }
    public boolean isActiva() { return activa; }

    public void cancelarReserva() {
        this.activa = false;
    }

    public void mostrarDetalle() {
        System.out.println("Reserva ID: " + idReserva);
        System.out.println("Usuario: " + usuario.getNombre());
        System.out.println("Recurso: " + recurso.getTitulo());
        System.out.println("Fecha: " + fechaReserva);
    }
}
