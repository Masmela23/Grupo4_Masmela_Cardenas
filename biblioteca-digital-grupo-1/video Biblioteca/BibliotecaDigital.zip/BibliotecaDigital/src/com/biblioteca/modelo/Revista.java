package com.biblioteca.modelo;

import com.biblioteca.interfaces.Prestable;
import com.biblioteca.interfaces.Descargable;

public class Revista extends RecursoDigital implements Prestable, Descargable {

    private int numeroEdicion;
    private String categoria;

    public Revista(String id, String titulo, String autor, int anio,
                   int numeroEdicion, String categoria) {
        super(id, titulo, autor, anio);
        this.numeroEdicion = numeroEdicion;
        this.categoria = categoria;
    }

    @Override
    public void mostrarInformacion() {
        System.out.println("📰 REVISTA: " + getTitulo());
        System.out.println("   Autor: " + getAutor() + " | Año: " + getAnioPublicacion());
        System.out.println("   Edición: " + numeroEdicion + " | Categoría: " + categoria);
        System.out.println("   Disponible: " + (isDisponible() ? "Sí" : "No"));
    }

    @Override
    public String getDescripcion() {
        return "Revista '" + getTitulo() + "' ed. " + numeroEdicion + " (" + categoria + ")";
    }

    @Override
    public void prestar(Usuario usuario) {
        if (!isDisponible()) {
            System.out.println("⚠ La revista '" + getTitulo() + "' no está disponible.");
            return;
        }
        setDisponible(false);
        System.out.println("✅ Revista '" + getTitulo() + "' prestada a " + usuario.getNombre());
    }

    @Override
    public void devolver() {
        setDisponible(true);
        System.out.println("✅ Revista '" + getTitulo() + "' devuelta al catálogo.");
    }

    @Override
    public String descargar() {
        return "⬇ Descargando revista '" + getTitulo() + "' en formato PDF...";
    }

    public int getNumeroEdicion() { return numeroEdicion; }
    public String getCategoria()  { return categoria; }
}
